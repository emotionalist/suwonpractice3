package com.cookandroid.suwonpractice3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class JoinMemberActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    Button backToLogin, checkEmail;
    LinearLayout checkLayout;
    private EditText editTextEmail;
    private EditText editTextPassword;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.joinmember);
        this.getSupportActionBar().hide();

        backToLogin = findViewById(R.id.backToLogin);
        mAuth = FirebaseAuth.getInstance();
        backToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        editTextEmail = (EditText)findViewById(R.id.userEmail);
        editTextPassword = (EditText)findViewById(R.id.userPW);

        Button SignUp = (Button) findViewById(R.id.registerBtn);

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createUser(editTextEmail.getText().toString(), editTextPassword.getText().toString());
            }
        });

    }
    private void createUser(String email, String password) {
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(JoinMemberActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(JoinMemberActivity.this, "회원가입 성공!", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(JoinMemberActivity.this, "회원가입 실패!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(JoinMemberActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    }