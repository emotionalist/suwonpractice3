package com.cookandroid.suwonpractice3;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.DefaultItemAnimator;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class ListFragment extends Fragment {

    ListViewAdapter adapter;
    ArrayList<Store> stores;
    ListView listView;

    Button sortname, sortrecent, sortstar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_list, container, false);
        FragmentManager fm = getActivity().getSupportFragmentManager();
        ActionBar actionBar = ((StartActivity)getActivity()).getSupportActionBar();
        actionBar.setTitle("전체목록");

        stores = new ArrayList<>();
        stores.add(new Store(1, R.drawable.salad, "에이샐러드", "샐러드, 샌드위치 등", "4.5점"));
        stores.add(new Store(2, R.drawable.chicken, "비치킨", "치킨 등", "4.1점"));
        stores.add(new Store(3, R.drawable.hamburger, "씨햄버거", "햄버거, 감자튀김 등", "3.7점"));
        stores.add(new Store(4, R.drawable.pizza, "디피자", "피자, 스파게티 등", "3.5점"));
        stores.add(new Store(5, R.drawable.salad, "이샐러드", "샐러드, 샌드위치 등", "4.5점"));
        stores.add(new Store(6, R.drawable.chicken, "에프치킨", "치킨 등", "4.1점"));
        stores.add(new Store(7, R.drawable.hamburger, "지햄버거", "햄버거, 감자튀김 등", "3.7점"));
        stores.add(new Store(8, R.drawable.pizza, "헤이치피자", "피자, 스파게티 등", "3.5점"));
        stores.add(new Store(9, R.drawable.salad, "아이샐러드", "샐러드, 샌드위치 등", "4.5점"));
        stores.add(new Store(10, R.drawable.chicken, "제이치킨", "치킨 등", "4.1점"));
        stores.add(new Store(11, R.drawable.hamburger, "케이햄버거", "햄버거, 감자튀김 등", "3.7점"));
        stores.add(new Store(12, R.drawable.pizza, "엘피자", "피자, 스파게티 등", "3.5점"));
        stores.add(new Store(13, R.drawable.salad, "엠샐러드", "샐러드, 샌드위치 등", "4.5점"));
        stores.add(new Store(14, R.drawable.chicken, "엔치킨", "치킨 등", "4.1점"));
        stores.add(new Store(15, R.drawable.hamburger, "오햄버거", "햄버거, 감자튀김 등", "3.7점"));
        stores.add(new Store(16, R.drawable.pizza, "피피자", "피자, 스파게티 등", "3.5점"));

        listView = (ListView) rootView.findViewById(R.id.list_custom);
        adapter = new ListViewAdapter(getContext(), stores);
        listView.setAdapter(adapter);

        sortname = rootView.findViewById(R.id.sortname);
        sortrecent = rootView.findViewById(R.id.sortrecent);
        sortstar = rootView.findViewById(R.id.sortstar);

        sortname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Comparator<Store> nameASC = new Comparator<Store>() {
                    @Override
                    public int compare(Store item1, Store item2) {
                        return item1.getStorename().compareTo(item2.getStorename());
                    }
                };
                Collections.sort(stores, nameASC);
                adapter.notifyDataSetChanged();
            }
        });

        sortrecent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Comparator<Store> recentASC = new Comparator<Store>() {
                    @Override
                    public int compare(Store item1, Store item2) {
                        return item1.getStorenum() - item2.getStorenum();
                    }
                };
                Collections.sort(stores, recentASC);
                adapter.notifyDataSetChanged();
            }
        });

        sortstar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Comparator<Store> starDESC = new Comparator<Store>() {
                    @Override
                    public int compare(Store item1, Store item2) {
                        return item2.getStorestar().compareTo(item1.getStorestar());
                    }
                };
                Collections.sort(stores, starDESC);
                adapter.notifyDataSetChanged();
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getActivity(), StoreActivity.class);
                startActivity(intent);
            }
        });


        setHasOptionsMenu(true);
        return rootView;
    }



    @Override
    public void onResume() {
        super.onResume();
        getActivity().invalidateOptionsMenu();
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menuaccount, menu);
        inflater.inflate(R.menu.menusearch, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.develope:
                Intent intent = new Intent(getActivity(), reportActivity.class);
                startActivity(intent);
                break;
            case R.id.logout:
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}